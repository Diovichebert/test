import AbstractView from "./AbstractView.js";
export default class extends AbstractView{
    constructor(){
        super();
        this.setTitle('My To Do List');
    }
    async getPage(){
        return `
        <div class="mainSite">
        <form action="/api/logout" method="post">
        <button type="submit">Logout</button>
        </form>
        <form id="todoForm">
        <h1> Your To Do Lists </h1>
        <br>
        <input id="toDoInp"><br>
        <br>
        <button type="button" id="addTaskButton">Add Task</button>
        </form>
        <div id="tasks"></div>
         </div>
    `;
    }
}



