const {Client} = require('pg');



const client = new Client({
    host: "localhost",
    user: "postgres",
    port: 5432,
    password: "root",
    database: "test", 
});

async function connectToDatabase(){
    try {
        await client.connect();
        console.log('Connected to database');
    } catch (error) {
        console.error('Error:',error.message);
    }
}

async function registerUser(username, email, password){
    try{
        const query = `
            INSERT INTO test (username, email, password)
            VALUES ($1, $2, $3)
        `;
        await client.query(query, [username, email, password]);
        console.log("User Registered!");

        return true;

    } catch(error){
        console.error('Error registering user:', error.message)
        console.log(('Registration Failed!'));

        return false;
    }
}

async function loginUser(username, password){
    try{
        const query = `
            SELECT * FROM test
            WHERE username = $1 AND password = $2
        `;
        const result = await client.query(query, [username, password]);
        
        if (result.rows.length === 1) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        console.error('Cannot Log In:', error.message);
        return false;
    }
}

module.exports = {
    connectToDatabase,
    registerUser,
    loginUser,
    getClient:() => client,
}
