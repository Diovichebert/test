const express = require('express');
const server = express();
const path = require('path');
const {connectToDatabase, registerUser, loginUser} = require('./usersDB.js');
const {requireAuth, authenticatedUsers} = require('./auth.js');


server.use(express.urlencoded({extended:true}));
server.use(express.json());

server.use('/script', express.static(path.resolve(__dirname, 'public', 'script')));

server.get('/mainview', requireAuth, (req,res)=>{
    res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
})

server.get('/*', (req, res) =>{
    res.sendFile(path.resolve(__dirname, 'public' , 'index.html'));
});

server.post('/api/registerform', async (req,res) =>{
   const username = req.body.username;
   const email = req.body.email;
   const password = req.body.password;
 

    await connectToDatabase();

    const regSuccess =  await registerUser(username, email, password);
     
    if(regSuccess){
        res.redirect('/loginform')
    } else {
        res.redirect('/regfail')
    }

});

server.post('/api/loginform', async (req,res) => {
    const username = req.body.username;
    const password = req.body.password;

    await connectToDatabase();

    const loginSuccess = await loginUser(username,password);
    
    if(loginSuccess){
        const sessionID = req.sessionID;
        authenticatedUsers[sessionID] = {username: username}
        res.redirect('/mainview');
    } else {
        res.redirect('/');
    }
})

server.post('/api/logout', (req,res)=>{
    const sessionID = req.sessionID;
    delete authenticatedUsers[sessionID];
    res.redirect('/');
})

server.listen(8080, () => {
    console.log('Server is running on port 8080');
})

