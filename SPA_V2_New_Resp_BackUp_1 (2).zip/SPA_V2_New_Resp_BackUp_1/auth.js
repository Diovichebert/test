const authenticatedUsers = {};

function requireAuth(req, res, next) {
  if (!authenticatedUsers[req.sessionID]) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  next();
}

module.exports = { requireAuth, authenticatedUsers };

  
  
  


